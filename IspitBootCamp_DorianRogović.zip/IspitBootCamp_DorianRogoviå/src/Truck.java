public class Truck extends Vehicle {
    private int cargoCapacity;

    public Truck(String make, String model, int yearOfProduction, String color, String vin, String fuelType, int cargoCapacity) {
        super(make, model, yearOfProduction, color, vin, fuelType);
        this.cargoCapacity = cargoCapacity;
    }

    public int getCargoCapacity() {
        return cargoCapacity;
    }
}
