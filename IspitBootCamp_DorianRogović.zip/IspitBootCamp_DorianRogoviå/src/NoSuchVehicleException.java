public class NoSuchVehicleException extends Exception{
    public NoSuchVehicleException(String message) {
        super(message);
    }
}
