import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        VehicleManager vehicleManager = new VehicleManagerImpl();
        Scanner scanner = new Scanner(System.in);

        boolean running = true;

        while (running) {
            System.out.println("Vehicle Fleet Management System:");
            System.out.println("1. Dodaj vozilo");
            System.out.println("2. Pretraži po proizvođaču ili modelu");
            System.out.println("3. Ispiši sva vozila");
            System.out.println("4. Obriši vozilo");
            System.out.println("5. Kraj");

            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {
                case 1:
                    System.out.println("Što želite dodati (1 - car, 2 - truck)?");
                    int vehicleType = scanner.nextInt();
                    scanner.nextLine();
                    switch (vehicleType) {
                        case 1:
                            System.out.println("Proizvođač:");
                            String make = scanner.nextLine();
                            System.out.println("Model:");
                            String model = scanner.nextLine();
                            System.out.println("Godina proizvodnje:");
                            int yearOfProduction = scanner.nextInt();
                            scanner.nextLine();
                            System.out.println("Boja:");
                            String color = scanner.nextLine();
                            System.out.println("VIN:");
                            String vin = scanner.nextLine();
                            System.out.println("Gorivo:");
                            String fuelType = scanner.nextLine();
                            System.out.println("Broj vrata:");
                            int numDoors = scanner.nextInt();
                            scanner.nextLine();
                            System.out.println("Karoserija:");
                            String bodyType = scanner.nextLine();
                            Vehicle car = new Car(make, model, yearOfProduction, color, vin, fuelType, numDoors,
                                    bodyType);
                            try {
                                vehicleManager.addVehicle(car);
                                System.out.println("Vozilo je uspješno dodano.");
                            } catch (DuplicateVehicleException e) {
                                System.out.println("Vozilo iste VIN oznake već postoji.");
                            }
                            break;
                        case 2:
                            System.out.println("Proizvođač:");
                            String make2 = scanner.nextLine();
                            System.out.println("Model:");
                            String model2 = scanner.nextLine();
                            System.out.println("Godina proizvodnje:");
                            int yearOfProduction2 = scanner.nextInt();
                            scanner.nextLine();
                            System.out.println("Boja:");
                            String color2 = scanner.nextLine();
                            System.out.println("VIN:");
                            String vin2 = scanner.nextLine();
                            System.out.println("Gorivo:");
                            String fuelType2 = scanner.nextLine();
                            System.out.println("Kapacitet tereta:");
                            int cargoCapacity = scanner.nextInt();
                            scanner.nextLine();
                            Vehicle truck = new Truck(make2, model2, yearOfProduction2, color2, vin2,
                                    fuelType2, cargoCapacity);
                            try {
                                vehicleManager.addVehicle(truck);
                                System.out.println("Vozilo je uspješno dodano.");
                            } catch (DuplicateVehicleException e) {
                                System.out.println("Vozilo iste VIN oznake već postoji.");
                            }
                            break;
                        default:
                            System.out.println("Nepoznat tip vozila!");
                            break;
                    }
                    break;
                case 2:
                    while (true) {
                        System.out.println("1. Pretraži po proizvođaču");
                        System.out.println("2. Pretraži po modelu");
                        System.out.print("Enter command: ");
                        String command = scanner.nextLine();

                        if (command.equals("1")) {
                            System.out.print("Unesi proizvođača: ");
                            String makeForSearch = scanner.nextLine();
                            List<Vehicle> searchResults = vehicleManager.searchVehicles(makeForSearch,
                                    null, null);
                            System.out.println("Rezultat: ");
                            for (Vehicle singleVehicle : searchResults) {
                                if (singleVehicle instanceof Car) {
                                    Car car = (Car) singleVehicle;
                                    System.out.printf("Car(make=\"%s\", model=\"%s\", year=%d, " +
                                                    "color=\"%s\", vin=\"%s\", fuelType=\"%s\", " +
                                                    "numDoors=%d, bodyType=\"%s\")\n",
                                            car.getMake(), car.getModel(), car.getYearOfProduction(),
                                            car.getColor(), car.getVin(), car.getFuelType(), car.getNumberOfDoors(),
                                            car.getBodyType());
                                } else if (singleVehicle instanceof Truck) {
                                    Truck truck = (Truck) singleVehicle;
                                    System.out.printf("Truck(make=\"%s\", model=\"%s\", year=%d, color=\"%s\", " +
                                                    "vin=\"%s\", fuelType=\"%s\", cargoCapacity=%d)\n",
                                            truck.getMake(), truck.getModel(), truck.getYearOfProduction(),
                                            truck.getColor(), truck.getVin(), truck.getFuelType(),
                                            truck.getCargoCapacity());
                                }
                            }
                        } else if (command.equals("2")) {
                            System.out.print("Pretraži model: ");
                            String modelForSearch = scanner.nextLine();
                            List<Vehicle> searchResults = vehicleManager.searchVehicles(null,
                                    modelForSearch, null);
                            System.out.println("Rezultat: ");
                            for (Vehicle singleVehicle : searchResults) {
                                if (singleVehicle instanceof Car) {
                                    Car car = (Car) singleVehicle;
                                    System.out.printf("Car(make=\"%s\", model=\"%s\", year=%d, color=\"%s\", " +
                                                    "vin=\"%s\", fuelType=\"%s\", numDoors=%d, bodyType=\"%s\")\n",
                                            car.getMake(), car.getModel(), car.getYearOfProduction(), car.getColor(),
                                            car.getVin(), car.getFuelType(), car.getNumberOfDoors(), car.getBodyType());
                                } else if (singleVehicle instanceof Truck) {
                                    Truck truck = (Truck) singleVehicle;
                                    System.out.printf("Truck(make=\"%s\", model=\"%s\", year=%d, color=\"%s\", " +
                                                    "vin=\"%s\", fuelType=\"%s\", cargoCapacity=%d)\n",
                                            truck.getMake(), truck.getModel(), truck.getYearOfProduction(),
                                            truck.getColor(), truck.getVin(), truck.getFuelType(), truck.getCargoCapacity());
                                }
                            }
                        } else {
                            System.out.println("Pogrešan unos. Molimo unesite broj 1 ili 2.");
                        }
                        break;
                    }
                    break;
                case 3:
                    List<Vehicle> allVehicles = vehicleManager.getAllVehicles();

                    for (Vehicle singleVehicle : allVehicles) {
                        if (singleVehicle instanceof Car) {
                            Car car = (Car) singleVehicle;
                            System.out.printf("Car(make=\"%s\", model=\"%s\", year=%d, " +
                                            "color=\"%s\", vin=\"%s\", fuelType=\"%s\", " +
                                            "numDoors=%d, bodyType=\"%s\")\n",
                                    car.getMake(), car.getModel(), car.getYearOfProduction(),
                                    car.getColor(), car.getVin(), car.getFuelType(), car.getNumberOfDoors(),
                                    car.getBodyType());
                        } else if (singleVehicle instanceof Truck) {
                            Truck truck = (Truck) singleVehicle;
                            System.out.printf("Truck(make=\"%s\", model=\"%s\", year=%d, color=\"%s\", " +
                                            "vin=\"%s\", fuelType=\"%s\", cargoCapacity=%d)\n",
                                    truck.getMake(), truck.getModel(), truck.getYearOfProduction(),
                                    truck.getColor(), truck.getVin(), truck.getFuelType(),
                                    truck.getCargoCapacity());
                        }
                    }
                    break;
                case 4:
                    System.out.print("Unesite VIN vozila koje želite obrisati: ");
                    String vinToDelete = scanner.nextLine();

                    try {
                        vehicleManager.removeVehicle(vinToDelete);
                        System.out.println("Vozilo s VIN " + vinToDelete + " je obrisano.");
                    } catch (NoSuchVehicleException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    running = false;
                    break;
                default:
                    System.out.println("Nepoznata komanda!");
            }
        }
    }
}


